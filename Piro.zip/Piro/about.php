<?php
$title = "About Us - InstaGold";
$metaD = "Contact Us";
include 'header.php';
?>

<div class="page-header"><div class="container"><div class="row justify-content-center"><div class="col-lg-8 col-xl-7 text-center"><h2 class="page-title">About Us</h2></div></div></div><!-- .container --></div>
<!-- About Section -->
<div class="page-content"><div class="container"><div class="col-lg-12"><div class="content-area card"><div class="card-innr card-innr-fix"><div class="gaps-1x"></div><!-- .gaps --><div class="card-head"><h4 class="card-title card-title-lg">History</h4><div class="gaps-1x"></div><!-- .gaps --><p>Instant Gold Nigeria was established in the year 2007. you can look this up on the All Who is Entry Website.</p>
<p>Instant Gold Nigeria is a total e-business solution provider that specializes in the provision of fast, reliable and efficient e-currency exchange service to the clients who desire to buy and sell online with ease. We are one of the World's most reliable and fastest link to the World of e-currency.  We help you convert your Cash to E-currency and we also help you convert your E-currency to Cash. We provide convenience for our clients in all areas of e-business.</p>
<p>Our mission is to provide unbeatable, un-equalled and unique e-commerce Solutions. We do not even allow you to take any risks. We bear all the risk and deliver our services to your doorsteps wherever you may be in the world. </p>
<div class="gaps-1x"></div><!-- .gaps -->
<h4 class="card-title card-title-lg">Who Are Our Customers?</h4><p>We provide services to large Online Forex Brokers, Internet Merchants, Exchangers, Consultancy Companies and Individuals, who prefer safe e-currency exchange, cash to e-currency or e-currency to cash services.</p>
</div></div><!-- .card-innr --></div><!-- .card --></div></div></div>
<div class="page-content"><div class="container"><div class="col-lg-12"><div class="content-area card"><div class="card-innr card-innr-fix"><div class="gaps-1x"></div><!-- .gaps --><div class="card-head"><h4 class="card-title card-title-lg">Why Are We Different?</h4><div class="gaps-1x"></div><!-- .gaps --><p>We are one of the largest e-currency exchangers providing services to large companies as well as to any client wishing to buy or sell small amount. Our customers have always up-to-date information about their orders thanks to our order-tracking facility. Incoming and outgoing payments are always processed on the same business day. </p>
<div class="gaps-1x"></div><!-- .gaps -->
<h4 class="card-title card-title-lg">Why Choose Us?</h4><p>Instant Gold Nigeria is dedicated to becoming the industry leader in e-currency and crypto-currency exchange, payment solutions and related services for companies and individuals worldwide. Instant Gold Nigeria was built on the principles of credibility and security. We are one of the very few oldest and long surviving exchange in the continent operating since 2007.</p>

<p>Over a decade we have been a part of the industry evolution and a solely pioneer of the ever used term - Instant Funding (the term widely used now by almost all exchanges/exchangers in the country).</p>
</div></div><!-- .card-innr --></div><!-- .card --></div></div></div>
<!--End About Section -->

<?php
include 'footer.php';
?>