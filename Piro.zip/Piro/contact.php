<?php
$title = "Contact Us - InstaGold";
$metaD = "Contact Us";
include 'header.php';
?>
<div class="page-header"><div class="container"><div class="row justify-content-center"><div class="col-lg-8 col-xl-7 text-center"><h2 class="page-title">Contact Us</h2></div></div></div><!-- .container --></div>
<!-- Contact Form -->
<div class="page-content"><div class="container"><div class="col-lg-12"><div class="content-area card"><div class="card-innr card-innr-fix"><div class="gaps-1x"></div><!-- .gaps --><form action="#"><div class="row"><div class="col-md-6"><div class="input-item input-with-label"><label class="input-item-label text-exlight">First Name</label><input class="input-bordered" type="text"></div></div><div class="col-md-6"><div class="input-item input-with-label"><label class="input-item-label text-exlight">Last Name</label><input class="input-bordered" type="text"></div></div></div><div class="input-item input-with-label"><label class="input-item-label text-exlight">Your Email</label><input class="input-bordered" type="text"></div><div class="input-item input-with-label"><label class="input-item-label text-exlight">Your Message</label><textarea class="input-bordered input-textarea"></textarea></div><div class="gaps-1x"></div><button class="btn btn-primary">Send Message</button></form></div><!-- .card-innr --></div><!-- .card --></div></div></div>
<!--End Contact Form -->

<div class="page-content"><div class="container"><div class="row"><div class="col-lg-6"><div class="content-area card"><div class="card-innr"><div class="card-head"><h6 class="card-title">LAGOS OFFICE (IKEJA)</h6></div><p><b>Address:</b> No 75, Mobolaji Bank Anthony Way, Ikeja Lagos.</p><p><b>Telephone:</b> 08062069637 | 09069922723</p><p><b>Email:</b> Support@instagold.ng</p><p><b>WhatsApp:</b> +234 806 206 9637</p></div><!-- .card-innr --></div><!-- .card --></div><!-- .col --><div class="col-lg-6"><div class="content-area card"><div class="card-innr"><div class="card-head"><h6 class="card-title">LAGOS OFFICE (IKEJA)</h6></div><p><b>Address:</b> No 75, Mobolaji Bank Anthony Way, Ikeja Lagos.</p><p><b>Telephone:</b> 08062069637 | 09069922723</p><p><b>Email:</b> Support@instagold.ng</p><p><b>WhatsApp:</b> +234 806 206 9637</p></div><!-- .card-innr --></div><!-- .card --></div></div></div><!-- .container --></div>
<?php
include 'footer.php';
?>