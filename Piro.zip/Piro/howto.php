<?php
$title = "How to - InstaGold";
$metaD = "KYC-Application";
include 'header.php';
?>
<div class="page-content"><div class="container"><div class="card content-area"><div class="card-innr"><div class="card-head"><h4 class="card-title card-title-lg">How To Buy E-currency using Insta Gold Nigeria</h4></div><div class="card-text"><p>Click on BUY E-CURRENCY</p>Input the desired amount of the E-currency you want to buy in US Dollar</p><p>Select the E-currency account type you want to buy/fund.</p>
<p>Click on PROCEED button to generate a payment invoice with the Transaction number. Copy down our bank information and the transaction reference number from this page. The same will be sent to your registered email.</p>
<p>Click on CONFIRM to record/save the transaction or click CANCEL to delete the transaction. (Note that only a confirmed invoice is valid and will be shown in your account history).</p>
<p>Once a transaction is confirmed, a successful confirmation message showing our bank information and the transaction reference number will be sent to your registered email. Please do check your spam box if you don't get this in the Inbox folder.</p>
</p><h5><strong>How to sell E-currency using Insta Gold Nigeria</strong></h5><p>Every legitimate project that sources funds through an ICO has a website, where they specify what the project is all about, its goals, the amount of money needed, how long the funding campaign will go on for and so forth.</p><p>Any customer willing to sell E-currency must have an iGN account (Verified or Non-verified).  CLICK HERE to open a new iGN account if you don't have one already or LOGIN HERE here with your username and password if you already registered.</p>
<p>From your iGN account, Click on SELL E-CURRENCY</p>
<p>Input the desired amount of E-currency you want to sell in US Dollar and select the type of E-currency.</p>
<p>Click on PROCEED to generate the invoice.</p>
<P>Make sure you read from the beginning of the invoice page to the end. Take note of your bank account information showing on the invoice page and make sure that it is correct before you proceed.</P>
<p>Click on PROCEED to start the withdrawal process on the E-currency Shopping Cart Interface or click on CANCEL to annul the particular withdrawal transaction.</p>
<p>If the withdrawal is completed successfully, A successful confirmation message, Batch number of the transaction and other transaction information are shown on the E-currency Shopping Cart Interface.</p>
<p>Click on RETURN TO MERCHANT or any other message that may show-up confirming the success of the the just concluded withdrawal.</p>
<p>You will automatically receive a confirmation message in your e-mail about the just concluded transaction and the status of the transaction will be shown as COMPLETED.</p>
<p>TAKE NOTICE: No need of writing us after the withdrawal. We will surely credit your bank account within 24 working hours. But in the case your order is not fulfilled after 24hrs. Chat with us using the live chat popup or leave an offline message.</p></div></div></div><!-- .card --></div><!-- .container --></div><!-- .page-content -->
<?php
include 'footer.php';
?>
